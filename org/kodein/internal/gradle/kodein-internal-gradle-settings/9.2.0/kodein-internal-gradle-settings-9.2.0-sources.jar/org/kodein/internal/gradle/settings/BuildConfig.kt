package org.kodein.`internal`.gradle.settings

import kotlin.String

internal object BuildConfig {
  internal const val kotlinVersion: String = "2.4.0"

  internal const val thisVersion: String = "9.2.0"
}
