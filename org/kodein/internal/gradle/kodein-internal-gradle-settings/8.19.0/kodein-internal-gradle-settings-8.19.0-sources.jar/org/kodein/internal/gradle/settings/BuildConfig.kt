package org.kodein.`internal`.gradle.settings

import kotlin.String

internal object BuildConfig {
  internal const val kotlinVersion: String = "2.3.20"

  internal const val thisVersion: String = "8.19.0"
}
